#include <STC12C5A60S2.H>
//#include "bsp_i2c.h"
//#include "delay.h"
//#include "bsp_mlx90614.h"
//#include "bsp_timer.h"
//#include "bsp_usart.h"


//void BSP_Init(void);

int mian(void)
{
//	printf("�ƶ����¶Ȳ��� /r/n");
//	BSP_Init();
	while(1)
	{
//		Display();
	}
}

//void BSP_Init(void)
//{
////	Timer0_Init();
//	InitUart();
//}