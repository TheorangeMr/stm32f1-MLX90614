#include "bsp_mlx90614.h"
#include "bsp_usart.h"
#include "delay.h"

float Ta = 13657.5;
extern u16 t;


void Mlx90614_Write(u8 dat)
{
	I2c_Start();
	I2c_WriteByte(0x00);
	I2c_WaitAck();
	I2c_WriteByte(0x2E);
	I2c_WaitAck();
	I2c_WriteByte(dat);
	I2c_WaitAck();
  I2c_WriteByte(0x00);
	I2c_WaitAck();
	I2c_Stop();
  delay_ms(5);                                                                  /*��ʱ���������ݲ�������д����*/
}


u16 Mlx90614_Read(u8 com)
{
	u8 Mlx_Hdat = 0;
	u8 Mlx_Ldat = 0;
	u8 pec = 0;
	u16 temperature = 0;
	I2c_Start();
	I2c_WriteByte(SA);
	I2c_WaitAck();
	I2c_WriteByte(com);
	I2c_WaitAck();
	I2c_Start();
	I2c_WriteByte(0x01);
	I2c_WaitAck();
	Mlx_Ldat = I2c_ReadByte();
	I2c_Ack(0);    /*Ӧ��*/
	Mlx_Hdat = I2c_ReadByte();
	I2c_Ack(0);
  pec= I2c_ReadByte();
	I2c_Ack(1);    /*��Ӧ��*/
	I2c_Stop();
	temperature = (Mlx_Hdat<<8)|Mlx_Ldat;
	return temperature;
}


void Display(com)
{
	u16 dat1 = 0;
//	if(t >= 20)
//	{
  	dat1 = Mlx90614_Read(com);
		Ta = dat1*0.02-273.15;
//		t = 0;
//		TR0 = 1;   /*������ʱ��0*/
		printf("environment temperature : %.2f ��\r\n",Ta);
	  delay_ms(1000);
//	}
}

//void READ_ID(void)
//{
//	dat = Mlx90614_Read(addr);
//	printf("%#x \r\n",dat);
//}