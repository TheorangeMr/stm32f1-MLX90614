#ifndef __BSP_MLX90614_H__
#define __BSP_MLX90614_H__

#include <STC12C5A60S2.H>
#include "delay.h"
#include "bsp_i2c.h"


#define SA				0x00 //�ӻ���ַ������MLX90614ʱ��ַΪ0x00,���ʱ��ַĬ��Ϊ0x5a
#define RAM_ACCESS		0x00 //RAM access command
#define EEPROM_ACCESS	0x20 //EEPROM access command
#define RAM_TOBJ1		0x07 //To1 address in the eeprom
#define RAM_TA		  0x06 //To1 address in the eeprom


u16 Mlx90614_Read(u8 com);
void Mlx90614_Write(u8 dat);
void Display(addr);




#endif  /*__BSP_MLX90614_H__*/