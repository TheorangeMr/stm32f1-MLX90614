#ifndef __BSP_I2C_H__
#define __BSP_I2C_H__

#include <STC12C5A60S2.H>
#include "delay.h"

void 	I2c_Start(void);
void I2c_Stop(void);
void I2c_Ack(u8 n);
void I2c_WaitAck(void);
void I2c_WriteByte(u8 dat);
u8 I2c_ReadByte(void);


#endif