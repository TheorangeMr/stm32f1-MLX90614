#include "bsp_i2c.h"

//sbit I2C_SDA = P1^1;
//sbit I2C_SCL = P1^0;

//sbit I2C_SDA2 = P1^3;
//sbit I2C_SCL2 = P1^2;

//sbit I2C_SDA3 = P1^5;
//sbit I2C_SCL3 = P1^4;

sbit I2C_SDA = P1^7;
sbit I2C_SCL = P1^6;


/*��ʼ�ź�*/
void 	I2c_Start(void)
{
  I2C_SDA = 1;                        /* 2 */
	I2C_SCL = 1;
	Delay_us(5);
  I2C_SDA = 0;
	Delay_us(5);
  I2C_SCL = 0;
}

/*�����ź�*/

void I2c_Stop(void)                    /* 1 */
{
	I2C_SCL = 0;
	Delay_us(5);	
  I2C_SDA = 0;
	Delay_us(5);
	I2C_SCL = 0;
	Delay_us(5);
  I2C_SDA = 1;
}


/*Ӧ���ź�*/

void I2c_Ack(u8 n)
{
	I2C_SDA = 1;
	Delay_us(1);	
	I2C_SDA = n;
	Delay_us(5);
	I2C_SCL = 1;
	Delay_us(5);
	I2C_SCL = 0;
}


/*�ȴ�Ӧ���ź�*/

void I2c_WaitAck(void)
{
	u8 times = 0;
	I2C_SDA = 1;
	Delay_us(5);
	if(I2C_SDA != 0)                                           /*��if�ж�ֻ����Ϊ���жϣ����޶�����Ӱ��I2CͨѶ*/
	{
			I2c_Stop();	
	}
//	while(I2C_SDA)
//	{
//		times++;
//		if(times>50)
//		{
//			I2c_Stop();
//			break;
//		}
//	}
	I2C_SCL = 1;
	Delay_us(5);
	I2C_SCL = 0;
	Delay_us(1);
}



/*��1Byte����*/

void I2c_WriteByte(u8 dat)
{
	u8 i;
	for(i = 0;i < 8;i++)
	{
		I2C_SDA = ((dat&0x80)>>7);                              /* 3 */
		dat <<= 1;
		I2C_SCL = 1;
		Delay_us(5);
		I2C_SCL = 0;
		Delay_us(5);
	}
}

/*��1Byte����*/
u8 I2c_ReadByte(void)
{
	u8 i;
	u8 dat;
	for(i = 0;i < 8;i++)
	{
		dat <<= 1;
		dat |= I2C_SDA;                                         /* 4 */
		I2C_SCL = 1;
		Delay_us(5);
		I2C_SCL = 0;
		Delay_us(5);
	}
	return dat;
}
