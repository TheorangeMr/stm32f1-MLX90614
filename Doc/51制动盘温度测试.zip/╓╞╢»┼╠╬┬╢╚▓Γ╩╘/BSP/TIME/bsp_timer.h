#ifndef __BSP_TIME_H__
#define __BSP_TIME_H__

#include <STC12C5A60S2.H>

void Timer0_Init();
//void Timer1_Init();

#endif  /*__BSP_TIME_H__*/