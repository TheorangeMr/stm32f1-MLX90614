#ifndef _DELAY_H
#define _DELAY_H

#include <STC12C5A60S2.H>
#include <intrins.h>

void Delay1ms();
void Delay1us();
void delay_ms(unsigned int t);
void Delay_us(unsigned char i);
#endif


