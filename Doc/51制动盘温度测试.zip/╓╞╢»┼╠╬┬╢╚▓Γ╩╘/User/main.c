#include <STC12C5A60S2.H>
#include "bsp_usart.h"
#include "bsp_i2c.h"
#include "delay.h"
#include "bsp_mlx90614.h"
#include "bsp_timer.h"
#include<intrins.h>
void BSP_Init(void)
{
	Timer0_Init();
	InitUart();
}


void main()
{
	BSP_Init();
//	Mlx90614_Write(0x01);
	printf("�ƶ����¶Ȳ���ʵ�� \r\n");
	while(1)
	{
//		Display(RAM_ACCESS|RAM_TA);
		Display(RAM_ACCESS|RAM_TOBJ1);
	}
}



